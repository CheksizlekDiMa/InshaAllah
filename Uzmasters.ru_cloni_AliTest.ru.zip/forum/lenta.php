<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'lenta';
require('../incfiles/core.php');
$lng_forum = core::load_lng('forum');
$textl = $lng_an['title'];
require_once ("../incfiles/head.php");
// Ограничиваем доступ к Форуму
$error = '';
if (!$set['mod_forum'] && $rights < 7)
    $error = $lng_forum['forum_closed'];
elseif ($set['mod_forum'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error) {
    echo '<div class="rmenu"><p>' . $error . '</p></div>';
    require('../incfiles/end.php');
    exit;
}
switch ($act) {
        case 'readed':
            /*
            -----------------------------------------------------------------
            Отмечаем все темы как прочитанные
            -----------------------------------------------------------------
            */
            $req = mysql_query("SELECT `forum`.`id`
            FROM `forum` LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
            WHERE `forum`.`type`='t'
            AND `cms_forum_rdm`.`topic_id` IS Null");
            while ($res = mysql_fetch_assoc($req)) {
                mysql_query("INSERT INTO `cms_forum_rdm` SET
                    `topic_id` = '" . $res['id'] . "',
                    `user_id` = '$user_id',
                    `time` = '" . time() . "'
                ");
            }
            $req = mysql_query("SELECT `forum`.`id` AS `id`
            FROM `forum` LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
            WHERE `forum`.`type`='t'
            AND `forum`.`time` > `cms_forum_rdm`.`time`");
            while ($res = mysql_fetch_array($req)) {
                mysql_query("UPDATE `cms_forum_rdm` SET
                    `time` = '" . time() . "'
                    WHERE `topic_id` = '" . $res['id'] . "' AND `user_id` = '$user_id'
                ");
            }
            header("Location: getdaily.php?&okread");
            exit;
             break;
     default:
             /*
            -----------------------------------------------------------------
            Вывод непрочитанных тем (для зарегистрированных)
            -----------------------------------------------------------------
            */
            $total = counters::forum_new();
           // echo '<div class="phdr"><a href="index.php"><b>' . $lng['forum'] . '</b></a> | ' . $lng['unread'] . '</div>';
echo' <div class="menu"><img src="'.$home.'/' . $_SESSION['path'].'images/forum.png" alt="" class="icon" style="padding: 0px; vertical-align: inherit; margin-bottom: -3px; margin-right: 4px;"><a href="getdaily.php"><b>Kunlik xabarlarga o\'tish</b></a></div>';
echo'<div class="menu"><img src="'.$home.'/' . $_SESSION['path'].'images/tick.png" alt="" class="icon" style="padding: 0px; vertical-align: inherit; margin-bottom: -3px; margin-right: 4px;"><a href="lenta.php?act=readed"><b>Hammasini o\'qilgan qilib belgilash</b></a></div>';
echo'<div class="phdr"><b>O\'qilmagan mavzular</b></div> ';
 if ($total > $kmess)
                echo '<div class="topmenu">' . functions::display_pagination('index.php?act=new&amp;', $start, $total, $kmess) . '</div>';
            if ($total > 0) {
                $req = mysql_query("SELECT * FROM `forum`
                LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
                WHERE `forum`.`type`='t'" . ($rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "
                AND (`cms_forum_rdm`.`topic_id` Is Null
                OR `forum`.`time` > `cms_forum_rdm`.`time`)
                ORDER BY `forum`.`time` DESC
                LIMIT $start, $kmess");
                for ($i = 0; $res = mysql_fetch_assoc($req); ++$i) {
                    if ($res['close'])
                        echo '<div class="rmenu">';
                    else
                        echo '<div class="menu">';
                    $q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type` = 'r' AND `id` = '" . $res['refid'] . "' LIMIT 1");
                    $razd = mysql_fetch_assoc($q3);
                    $q4 = mysql_query("SELECT `id`, `text` FROM `forum` WHERE `type`='f' AND `id` = '" . $razd['refid'] . "' LIMIT 1");
                    $frm = mysql_fetch_assoc($q4);
                    $colmes = mysql_query("SELECT `user_id`,`from`, `time` FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
                    $colmes1 = mysql_num_rows($colmes);
                    $cpg = ceil($colmes1 / $kmess);
                    $nick = mysql_fetch_assoc($colmes);
                     //---------------
                      $staym = mysql_fetch_assoc(mysql_query("SELECT `time` FROM `cms_forum_rdm` WHERE `topic_id` = '".$res['id']."' and `user_id` = '".$user_id."'"));
                     $opos = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " AND `time` > '".$staym['time']."' "), 0);
                    //------------------


echo'
Podforum: <b><a href="index.php?id=' . $razd['id'] . '">' . $razd['text'] . '</a><span style="color: red; font-weight: bold;"> +'.$opos.'</span></b><div class="br"></div>
Mavzu: <b><a href="index.php?id=' . $res['id'] . ($cpg > 1 && $set_forum['upfp'] && $set_forum['postclip'] ? '&amp;clip' : '') . ($set_forum['upfp'] && $cpg > 1 ? '&amp;page=' . $cpg : '') . '">' . $res['text'] .'</a></b>&#160;(' . $colmes1 . ') <div class="br"></div>
Javob berdi: <b><a href="'.$home.'/users/profile.php?user='.$nick['user_id'].'">'.$nick['from'].'</a></b> (' . functions::display_date($nick['time']) . ')<div class="br"></div>
Sahifa: &#160;<a href="index.php?id=' . $res['id'] . (!$set_forum['upfp'] && $set_forum['postclip'] ? '&amp;clip' : '') . ($set_forum['upfp'] ? '' : '&amp;page=' . $cpg) . '">&gt;&gt;&gt;</a></div>';

                }
            } else {
               header("Location: getdaily.php");
                  exit;
            }


 break;
}
require_once('../incfiles/end.php');