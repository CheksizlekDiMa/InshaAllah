<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Please, try again later</title>
</head>
<body>
<div style="text-align: center">
<h2 style="color:red">Attention!</h2><br/>
The site carried out technical work.<br/>Please, try again later
</div>
</body>
</html>