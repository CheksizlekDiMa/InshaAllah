<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
if (!empty($cms_ads[2])) {
    echo '<div class="gmenu">' . $cms_ads[2] . '</div>';
}

echo '</div>';
/*if (isset($_GET['err']) || $headmod != "mainpage" || ($headmod == 'mainpage' && $act)) {
    echo '<div><a href=\'' . $set['homeurl'] . '\'>' . functions::image('menu_home.png') . $lng['homepage'] . '</a></div>';
}*/
$fpost =  mysql_result(mysql_query("SELECT COUNT(`id`) FROM `forum` WHERE `type` = 'm' "), 0);
$fmav =  mysql_result(mysql_query("SELECT COUNT(`id`) FROM `forum` WHERE `type` = 't' "), 0);
$sazo = mysql_fetch_assoc(mysql_query("SELECT `id`,`name` FROM `users` ORDER BY `id` DESC LIMIT 1"));

echo'<div class="tmn">'.
'<div>' . counters::online() . '</div>'.
'<div><a href="'.$home.'/users/profile.php"><img src="'.$home.'/theme/default/images/menu_cabinet.png" alt="-" class="icon"> Shaxsiy profil</a><br></div>'.
'<div><a href="'.$home.'/forum/search.php"><img src="'.$home.'/theme/default/images/tool.png" alt="-" class="icon"> Forumdan qidirish</a><br></div>'.
($headmod == "mainpage" ? '<div> - Faol mavzular soni: <b> ' . $fmav . '</b></div>' : '').
($headmod == "mainpage" ? '<div> - Barcha xabarlar soni:<b> '.$fpost.'</b></div>' : '').
($headmod == "mainpage" ? '<div>- Forum a`zolari: <b>' . counters::users() . ' kishi</b></div>' : '').
($headmod == "mainpage" ? '<div>- So`ngi a`zo: <b> <a href="'.$home.'/users/profile.php?user='.$sazo['id'].'" alt="">'.$sazo['name'].'</a></b></div>' : '').
($headmod != "mainpage" ? '<div><a href=\'' . $set['homeurl'] . '\'>' . functions::image('menu_home.png') . $lng['homepage'] . '</a></div>' : '').
'</div>';
/*echo '<div>' . counters::online() . '</div>' .
    '</div>' .
    '<div style="text-align:center">' .
    '<p><b>' . $set['copyright'] . '</b></p>';
*/
// Счетчики каталогов
functions::display_counters();

// Рекламный блок сайта
/*if (!empty($cms_ads[3])) {
    echo '<br />' . $cms_ads[3];
}*/

/*
-----------------------------------------------------------------
ВНИМАНИЕ!!!
Данный копирайт нельзя убирать в течение 90 дней с момента установки скриптов
-----------------------------------------------------------------
ATTENTION!!!
The copyright could not be removed within 90 days of installation scripts
-----------------------------------------------------------------
*/
echo '<div><small>&copy; <a href="'.$home.'">AliForum</a></small></div>' .
    '</div></body></html>';