Uzbek language pack v1.1
============================================================
 TIL PAKET HAQIDA:
 Ushbu til paket JohnCMS uchun mo'ljallangan.
Til paket Sard0r(go_sari@mail.ru) tarjimasi asosida qayta taxrirlangan.
Til paketni qayta taxrirlashda quyidagi masterlar jonbozlik ko'rsatishgan:
  - GeniuSBoY
  - Udesign
  - MoRGaN
  - AspironSV 
  - Operator_N1
  - Alibi89 
============================================================
JohnCMS v6x uchun o'zbekcha til paketi.
Modul paketchalari:
         - _core.lng
         - admin.lng
		 - ban.lng
		 - downloads.lng
		 - faq.lng
		 - forum.lng
		 - gallery.lng
		 - karma.lng
		 - library.lng
		 - mail.lng
		 - news.lng
		 - pass.lng
		 - places.lng
		 - profile.lng
		 - registration.lng
		 - settings.lng
		 - smileys.lng
==========================================================
ESLATMA: Til paketida xatoliklar ko'rsangiz yoki takliflar bo'lsa
bizning forumga murojaat qiling: http://uzfor.net/view.php?act=theme&id=980&start=120		 