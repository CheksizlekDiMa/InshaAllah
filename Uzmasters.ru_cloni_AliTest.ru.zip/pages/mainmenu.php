<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

//$mp = new mainpage();

echo'<div class="menu">
    <a href="'.$home.'/forum/getdaily.php">Kunlik xabarlar</a> |
    <a href="'.$home.'/forum/getdaily.php?act=kunlik&amp;soat=12">12s</a> |
    <a href="'.$home.'/forum/getdaily.php?act=kunlik&amp;soat=48">48s</a> |
    <a href="'.$home.'/forum/getdaily.php?act=kunlik&amp;soat=72">72s</a><br>

    <a href="'.$home.'//top.php">Top-list</a> |
    <a href="'.$home.'/ban.php">Ban-list</a> |
    <a href="'.$home.'/users.php?act=moders">Ma`muriyat</a><br>

    <a href="'.$home.'/forum/malumotnoma.php">F.A.Q</a> |
    <a href="'.$home.'/qoida.php">Qoidalar</a> |
    <a href="'.$home.'/forum/search.php">Forumdan izlash</a><br>

    <a href="'.$home.'/group.php">Savdogarlar</a> |
    <a href="'.$home.'/pages/fraudsters/">Firibgarlar</a> |
    <a href="'.$home.'/dokon/index.php">Forum do`koni</a><br>

    <a href="'.$home.'/forum/avatar/">Avatar yasash</a> |
    <a href="'.$home.'/forum/pay.php">Hisobni to`ldirish</a> |
    <a href="'.$home.'/forum/bowling/">Bowling o`yini</a>
</div>';
echo'<div class="phdr"><b>YANGILIKLARIMIZ (15)</b></div>';
echo'<div class="menu">
                <img src="'.$home.'/images/forum.png" alt="#" class="icon">
                <b>Yangi qo`shimcha(lar)!</b> (13:32:23, 15 Mar 2018)<br>-
                <a href="'.$home.'/view.php?id=24029">Bildirilgan fikrlar</a> 17
            </div>';
  $for = mysql_query("SELECT * FROM `forum`  WHERE `type` = 'f' ORDER BY `realid` ASC LIMIT " . $start . "," . $kmess." ");
              while($f = mysql_fetch_assoc($for)) {
                      echo '<div class="phdr"><b>' . $f['text'] . '</b></div>';
                     $pfid =  $f['id'];

                $forum2 = mysql_query("SELECT * FROM `forum`  WHERE `refid` = '".$f['id']."' and `type` = 'r' ORDER BY `realid` ASC LIMIT " . $start . "," . $kmess." ");
                               while($fb = mysql_fetch_assoc($forum2)) {
                                 $countm = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '".$fb['id']."' and `type` = 't'"), 0);
                                   //echo '<div class="menu"> &bull;&nbsp;<a href="forum/index.php?id='.$fb['id'].'">'.$fb['text'].'</a><span class="chet"><span style="color: #CCCB8B">[</span>'.$countm.'<span style="color: #C5CC85">]</span></span></div>';
                            echo'<div class="menu"><img src="' . $home . '/images/2.png" alt="-" style="width: 14px; margin-bottom: -3px;"> <a href="forum/index.php?id='.$fb['id'].'">'.$fb['text'].'</a> ['.$countm.']</div>';
                 }
              }
              mail ("mail_zero@mail.ru", "Подтверждение подписки alitest.ru", "salom", "From: mailzero2015@gmail.com");
?>
